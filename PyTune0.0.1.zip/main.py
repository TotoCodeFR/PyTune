import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import vlc
import os

class MediaPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("Media Player")
        self.root.geometry("600x400")

        self.instance = vlc.Instance()
        self.player = self.instance.media_player_new()
        self.background_music = self.instance.media_player_new()
        
        # Load a background music file (change the path to your own background music file)
        self.background_music_media = self.instance.media_new("assets/background.mp3")
        self.background_music.set_media(self.background_music_media)
        self.background_music.audio_set_volume(20)  # Adjust the volume as needed
        self.background_music.play()

        self.icon = Image.open("assets/icon.png")
        self.iconLoad = ImageTk.PhotoImage(self.icon)
        self.iconLabel = tk.Label(image=self.iconLoad)
        self.iconLabel.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        
        # Create a frame at the bottom for buttons
        sidebar_frame = tk.Frame(root)
        sidebar_frame.pack(side=tk.BOTTOM, fill=tk.X)

        self.title_label = tk.Label(sidebar_frame, text="No media playing")
        self.title_label.pack(side=tk.LEFT)
        empty_label = tk.Label(sidebar_frame, text="")
        empty_label.pack(side=tk.LEFT, expand=True, fill='x')

        self.play_button = tk.Button(sidebar_frame, text="Play", command=self.play)
        self.pause_button = tk.Button(sidebar_frame, text="Pause", command=self.pause)
        self.resume_button = tk.Button(sidebar_frame, text="Resume", command=self.resume)
        self.stop_button = tk.Button(sidebar_frame, text="Stop", command=self.stop)

        self.play_button.pack(side=tk.LEFT)
        self.pause_button.pack(side=tk.LEFT)
        self.resume_button.pack(side=tk.LEFT)
        self.stop_button.pack(side=tk.LEFT)

        self.is_media_playing = False

    def play(self):
        media_path = filedialog.askopenfilename(filetypes=[('Media Files', ('*.mp3', '*.avi', '*.mp4'))])
        if media_path:
            if not self.is_media_playing:
                self.stop_background_music()
            media = self.instance.media_new(media_path)
            self.player.set_media(media)
            self.player.set_hwnd(self.root.winfo_id())  # Set the window ID for video playback
            self.player.audio_set_volume(50)
            self.player.play()
            filename = os.path.basename(media.get_mrl())
            self.title_label.config(text=f"Media Title: {filename}")
            self.is_media_playing = True

    def pause(self):
        if self.is_media_playing and self.player.get_state() == vlc.State.Playing:
            self.player.pause()

    def resume(self):
        if self.is_media_playing and self.player.get_state() == vlc.State.Paused:
            self.player.play()

    def stop(self):
        self.title_label.config(text=f"No media playing")
        if self.is_media_playing:
            self.player.stop()
            self.resume_background_music()
            self.is_media_playing = False

    def stop_background_music(self):
        self.background_music.stop()

    def resume_background_music(self):
        self.background_music.audio_set_volume(20)  # Adjust the volume as needed
        self.background_music.play()

if __name__ == "__main__":
    root = tk.Tk()
    app = MediaPlayer(root)
    root.mainloop()
